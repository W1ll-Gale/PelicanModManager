# Pelican Minecraft Mod Manager

A Minecraft mod and plugin manager for Pelican server panels, using Modrinth.

This is a standalone fork of the original [Minecraft Modrinth](https://hub.pelican.dev/plugins/minecraft-modrinth) plugin by Boy132 & H1ghSyst3m, with major performance improvements and card layout styling changes.

## Features

- **Modrinth Search**: Search and filter mods, plugins, and modpacks inside your server panel.
- **Smart Installs**: Automatically downloads the latest compatible version based on your server loader and Minecraft version.
- **Status & Updates**: View installed mods, available updates, and manage them.
- **Toggle switch**: Enable/disable mods directly by renaming `.jar` files to `.jar.disabled`.
- **Local files**: Manage and delete local files not tracked by Modrinth.

## Setup

### Panel Installation

1. Download the latest `pelican-mod-manager.zip`.
2. Extract the archive into your Pelican panel's root `plugins` folder:
   ```bash
   unzip pelican-mod-manager.zip -d /var/www/pelican/plugins/
   ```
3. Run:
   ```bash
   composer dump-autoload
   php artisan config:clear
   php artisan view:clear
   ```

### Egg Setup

Configure your egg with the following:

- **Features**: Add `modrinth_mods` and/or `modrinth_plugins` to the `features` array.
- **Minecraft Tag**: The egg must have the `minecraft` tag.
- **Loader Tag**: Add the loader tag (e.g. `paper`, `purpur`, `fabric`, `neoforge`, `forge`, `quilt`).

## Credits & Acknowledgements

Based on the original **Minecraft Modrinth** plugin by:
- **Boy132** (Lead Developer)
- **H1ghSyst3m** (Co-developer)

Forked and improved by **MrBytesized** to add directory caching, UI card layouts, and enable/disable toggles.

## License
MIT
